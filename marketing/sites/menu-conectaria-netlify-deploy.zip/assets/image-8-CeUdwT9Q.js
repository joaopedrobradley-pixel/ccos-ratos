const s="/assets/image-8-D3w14iO7.webp";export{s as c};
