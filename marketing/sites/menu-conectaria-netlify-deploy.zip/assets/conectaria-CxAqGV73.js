const a="/assets/conectaria-Del7n31r.webp";export{a as b};
