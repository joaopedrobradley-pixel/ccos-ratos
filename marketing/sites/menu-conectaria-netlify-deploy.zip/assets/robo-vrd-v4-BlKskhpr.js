const o="/assets/robo-vrd-v4-BrT5YJGn.webp";export{o as r};
