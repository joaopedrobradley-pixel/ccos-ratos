const o="/assets/joao-mockup-DXuojxP9.webp";export{o as j};
